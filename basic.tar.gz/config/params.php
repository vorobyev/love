<?php

return [
    'key1'=>'dvtcntvscbkf',//вместемысила (англ.)
    'key2'=>'vskexitdct[',//мылучшевсех (англ.)
    'uploadPath'=>dirname(__DIR__) .'/web/image',
    'uploadUrl'=>'image',
    'adminEmail' => 'admin@example.com',
];
