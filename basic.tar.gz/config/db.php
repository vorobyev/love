<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=love',
    'username' => 'root',
    'password' => 'dfvgbh',
    'charset' => 'utf8',
];
