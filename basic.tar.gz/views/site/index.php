<?php
use dosamigos\fileupload\FileUploadUI;
/* @var $this yii\web\View */
$this->title = 'Наш склад счастья';
?>
<div class="site-index">
<br/>
<div class="content-index">Сайт Воробьева Михаила и Литовкиной Натальи! </div>
 <div class="content-index">Содержит немного событий из нашей жизни.</div>
  <img src="imageSite/snowmens.jpg"/>
<div class="left-index"><img src="imageSite/2.png"/></div>
</div>
