<?php
use evgeniyrru\yii2slick\Slick;
use yii\helpers\Html;
use yii\web\JsExpression;
use app\assets\AppAssetSurprise;


$this->title = 'Всячина';
$this->params['breadcrumbs'][] = $this->title;
//AppAssetSurprise::register($this);


?>
<div class="site-index">  
<br/>
    В разработке

</div>
