<?php
use evgeniyrru\yii2slick\Slick;
use yii\helpers\Html;
use yii\web\JsExpression;
use app\assets\AppAssetSurprise;


$this->title = 'События';
$this->params['breadcrumbs'][] = $this->title;
//AppAssetSurprise::register($this);

$this->registerJs("
snowStorm.stop();");
?>
<div class="site-index">  
<br/>
    В разработке

</div>
